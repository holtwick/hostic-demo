Minor bugfix
