Preparing the next features
